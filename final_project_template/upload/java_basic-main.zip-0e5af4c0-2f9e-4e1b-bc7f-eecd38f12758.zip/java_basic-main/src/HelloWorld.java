class HelloWorld  {
	public static void main(String[] args) {
		System.out.println("안녕하세요. 자바");
		System.out.println(30);
		System.out.println(3.14);
		System.out.println('남');
		System.out.println(true);
		System.out.println("깃 테스트를 위한 코드 추가....");
	}

}
