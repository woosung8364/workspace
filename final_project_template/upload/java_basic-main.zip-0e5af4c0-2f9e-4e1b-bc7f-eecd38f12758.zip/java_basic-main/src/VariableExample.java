class VariableExample {
	public static void main(String[] args) {
		String name;
		int age;
		double weight;

		name = "김기정";
		age = 30;
		weight = 67.8;

		System.out.println(name);
		System.out.println(name);
		System.out.println(name);
		System.out.println(name);
		System.out.println(age);
		System.out.println(weight);

		name = "홍길동";
		age = 40;
		weight = 68.5;

		System.out.println(name);
		System.out.println(age);

		int age2;
		age2 = age;
		System.out.println(age2);

		int score = 95;

		int a = 10, b = 20, c = 30, d = 40, e = 50;
		System.out.println(e);

		int x = 100;
		System.out.println(x);

		String firstName = "기정"; 
		String lastName = "김";

		//int this;
		String 이름 = "홍기동";
		System.out.println(이름);
	}
}
