
public class EclipseExample {

	public static void main(String[] args) {

		String message = "이클립스 연습입니다.";
		int age = 30;
		double weight = 75.5;
		
		System.out.println(message);
		System.out.println(age);
		System.out.println(weight);
		
		System.err.println("에러내용입니다.");
		
	}

}
