class CommentExample {
	
	// 자바 프로그램의 실행 진입점 역할의 메소드(엔트리 포인트)
	public static void main(String[] args) {
		
		// 커맨드창에 텍스트를 출력하는 방법 3가지
		
		
		System.out.println("출력 후 라인을 바꿔주는 방법");
		System.out.print("출력 후 라인 바꾸지 않는 방법");
		System.out.printf("%s", "배종현입니다.");

	}
}
