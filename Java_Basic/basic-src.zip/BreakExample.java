
//		break 이동문

public class BreakExample {

	public static void main(String[] args) {

		for (int i = 0; i < 100; i++) {
			System.out.println("출력 = " + i);
			if (i == 50) {
				break;
			}
		}
		
		
	}

}
