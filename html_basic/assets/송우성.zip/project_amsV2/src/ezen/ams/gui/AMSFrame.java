package ezen.ams.gui;

import java.awt.Button;
import java.awt.Choice;
import java.awt.FlowLayout;
import java.awt.Frame;
import java.awt.Label;
import java.awt.TextArea;
import java.awt.TextField;

import ezen.awt.EventExampleFrame;

public class AMSFrame extends Frame {

//	컴포넌트 배치를 위한 변수선언

	// 계좌 번호 1
	Label acNum;

	// 계좌 종류 2
	Label acType;

	// 계좌 주인 3
	Label acOwner;

	// 계좌 비밀번호 4
	Label acPasswd;

	// 입금 금액 5
	Label deMoney;

	// 대출 금액 6
	Label BwMoney;

	// 계좌 목록 7
	Label acList;

	// 단위 (원) 8
	Label unit;

	// 버튼 (총 5개)
	Button button1, button2, button3, button4, button5;

	// 택스트 필드 (총 5개)
	TextField tf1, tf2, tf3, tf4, tf5;

	// 입출금 , 마이너스 계좌
	Choice choice;

	// 계좌 목록 - 출력화면
	TextArea acListMonitor;

//	AMSFrame 생성자 초기화

	public AMSFrame() {
		this("");
	}

	public AMSFrame(String title) {
		super(title);

		// 라벨 초기화
		acType = new Label("계좌종류");
		acNum = new Label("계좌번호");
		acOwner = new Label("예금주명");
		acPasswd = new Label("비밀번호");
		deMoney = new Label("입금금액");
		BwMoney = new Label("대출금액");
		acList = new Label("계좌목록");
		unit = new Label("(단위 : 원)");

		// 선택칸 메소드
		choice = new Choice();
		choice.add("출금계좌");
		choice.add("마이너스계좌");

		// 텍스트 필드 초기화
		tf1 = new TextField(20);
		tf2 = new TextField(20);
		tf3 = new TextField(20);
		tf4 = new TextField(20);
		tf5 = new TextField(20);

		// 버튼 초기화
		button1 = new Button("조회");
		button2 = new Button("삭제");
		button3 = new Button("검색");
		button4 = new Button("신규등록");
		button5 = new Button("신규조회");

	}

	// 컴포넌트 배치
	public void init() {

		setLayout(new FlowLayout());
		add(button1);
		add(button2);
		add(tf);
		add(choice);
	}

	

	

			
		public static void main(String[] args) {
//			타이틀 선정을 위한 생성자 호출
		Frame frame = new Frame("EZEN-BANK AMS");
		frame.init();
		frame.eventHandling();
		frame.setSize(500, 400);
		frame.setVisible(true);
	}
			
			
}
