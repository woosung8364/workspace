package ezen.ams.app;

import java.util.Scanner;

import ezen.ams.domain.Account;
import ezen.ams.domain.AccountRepository;
import ezen.ams.domain.FileAccountRepository;
import ezen.ams.domain.MemoryAccountRepository;
import ezen.ams.domain.MinusAccount;

public class AMS {

//	객체 사용을 위한 호출 Account , MemoryAccountRepository
	Account account = new Account();
	private static AccountRepository repository = new MemoryAccountRepository();
	private static Scanner scanner = new Scanner(System.in);

//	첫 인터페이스 조작시 출력화면
	public static void main(String[] args) {
		System.out.println("*****************************************");
		System.out.println("** " + Account.BANK_NAME + " 은행 계좌 관리 애플리케이션 **");
		System.out.println("*****************************************");

// 계좌 조회를 위한 가상데이터 임시 등록

		repository.addAccount(new Account("김기정", 1111, 100000000));
		repository.addAccount(new Account("강소영", 1234, 100000000));
		repository.addAccount(new Account("이희영", 1234, 100000000));
		repository.addAccount(new Account("김기정", 1111, -10000));

		boolean run = true;

		while (run) {
			System.out.println("----------------------------------------------");
			System.out.println("1.계좌생성|2.계좌목록|3.입금|4.출금|5.종료");
			System.out.println("----------------------------------------------");
			System.out.print("선택> ");

//			parseInt는 문자열을 입력하면 정수타입인 int로 변환하게 해줍니다.
			int selectNo = Integer.parseInt(scanner.nextLine());

			if (selectNo == 1) {
				// 계좌 생성 및 등록
				createAccount();
			} else if (selectNo == 2) {
				// 계좌목록
				printAccounts();
			} else if (selectNo == 3) {
				// 입금
			} else if (selectNo == 4) {
				// 출금
			} else if (selectNo == 5) {
				run = false;
			}
		}
//		scanner는 사용후에도 가비지 컬렉터의 메모리관리대상에서 제외되므로
//		수동종료 해줘야합니다.

		scanner.close();
		System.out.println("계좌관리 애플리케이션을 종료합니다.");
	}

	/**
	 * 키보드(표준입력)로부터 계좌정보 입력 받아 계좌생성하기
	 */
	private static void createAccount() {

		System.out.print("예금주명: ");
		String owner = scanner.nextLine();

		System.out.print("비밀번호: ");
		int passwd = Integer.parseInt(scanner.nextLine());

		System.out.print("입금액: ");
		long inputMoney = Long.parseLong(scanner.nextLine());

		Account account = new Account(owner, passwd, inputMoney);

// AccountRepository에 새로운 계좌를 등록합니다.
//		메소드 호출
		repository.addAccount(account);
		System.out.println("※ 계좌 정상 등록 처리되었습니다.");
	}

	/**
	 * 등록된 전체계좌 목록 출력
	 */

	private static void printAccounts() {
//		계좌 정보를 보기 위한 화면 출력
		System.out.println("----------------------------------------------");
		System.out.println("계좌유형        번호   예금주 비밀번호   잔액");
		System.out.println("----------------------------------------------");

//		Account[] 배열의 list는 repository에 저장된 전체계좌이다.
		Account[] list = repository.getAccounts();
//		getCount는 계좌의 갯수 루프가 돌아가면서 전체 계좌의 갯수를 셉니다.
		for (int i = 0; i < repository.getCount(); i++) {
//			만약 전체계좌의 잔돈이 0보다 크다면
			if (list[i].getRestMoney() > 0) {
//				0보다 큰 계좌의 정보를 출력합니다
				System.out.println(list[i].toString());
			} else if (list[i].getRestMoney() < 0) {
//				만약 잔고가 0보다 작은 계좌가 있다면
				MinusAccount type = new MinusAccount();
//				마이너스 계좌의 정보를 출력합니다
				System.out.println(type.toString());
			}

		}
	}

}
