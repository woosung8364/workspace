package ezen.ams.domain;

public class FileAccountRepository implements AccountRepository {

	
	
	
	
	@Override
	public int getCount() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public Account[] getAccounts() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean addAccount(Account account) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public Account searchAccount(String accountNum) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Account[] searchAccountByOwner(String accountOwner) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean removeAccout(String accountNum) {
		// TODO Auto-generated method stub
		return false;
	}

}
